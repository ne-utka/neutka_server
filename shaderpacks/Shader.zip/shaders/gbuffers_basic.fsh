#version 330 compatibility
#include "/include/gbuffers_basic.fsh"
