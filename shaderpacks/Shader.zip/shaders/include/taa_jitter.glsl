#ifndef NEUTKA_TAA_JITTER_GLSL
#define NEUTKA_TAA_JITTER_GLSL

#include "/settings.glsl"

#ifdef TAA_ENABLED
uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;

vec2 taaJitterOffset(int frameIndex) {
    const vec2 offsets[8] = vec2[8](
        vec2( 0.0000, -0.1667),
        vec2(-0.2500,  0.1667),
        vec2( 0.2500, -0.3889),
        vec2(-0.3750, -0.0556),
        vec2( 0.1250,  0.2778),
        vec2(-0.1250, -0.2778),
        vec2( 0.3750,  0.0556),
        vec2(-0.4375,  0.3889)
    );
    return offsets[frameIndex & 7] * TAA_JITTER_STRENGTH;
}

void applyTaaJitter(inout vec4 clipPosition) {
    vec2 resolution = max(vec2(viewWidth, viewHeight), vec2(1.0));
    float viewDistance = abs(clipPosition.w);
    float distantGeometry = smoothstep(TAA_JITTER_FADE_START,
                                       TAA_JITTER_FADE_END,
                                       viewDistance);
    float jitterScale = mix(1.0, TAA_DISTANT_JITTER_MIN, distantGeometry);
    clipPosition.xy += taaJitterOffset(frameCounter) * jitterScale
        * (2.0 / resolution) * clipPosition.w;
}
#else
void applyTaaJitter(inout vec4 clipPosition) {
}
#endif

#endif
