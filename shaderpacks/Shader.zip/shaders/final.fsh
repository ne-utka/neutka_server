#version 330 compatibility

#include "/settings.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texCoord;

float fxaaLuma(vec3 color) {
    return dot(color, vec3(0.299, 0.587, 0.114));
}

vec4 stableFxaa(vec2 uv) {
    vec2 inverseResolution = 1.0 / max(vec2(viewWidth, viewHeight), vec2(1.0));
    vec4 center = texture(colortex0, uv);

    vec3 northWest = texture(colortex0, uv + inverseResolution * vec2(-1.0,  1.0)).rgb;
    vec3 northEast = texture(colortex0, uv + inverseResolution * vec2( 1.0,  1.0)).rgb;
    vec3 southWest = texture(colortex0, uv + inverseResolution * vec2(-1.0, -1.0)).rgb;
    vec3 southEast = texture(colortex0, uv + inverseResolution * vec2( 1.0, -1.0)).rgb;

    float lumaCenter = fxaaLuma(center.rgb);
    float lumaNorthWest = fxaaLuma(northWest);
    float lumaNorthEast = fxaaLuma(northEast);
    float lumaSouthWest = fxaaLuma(southWest);
    float lumaSouthEast = fxaaLuma(southEast);

    float lumaMinimum = min(lumaCenter, min(min(lumaNorthWest, lumaNorthEast),
                                             min(lumaSouthWest, lumaSouthEast)));
    float lumaMaximum = max(lumaCenter, max(max(lumaNorthWest, lumaNorthEast),
                                             max(lumaSouthWest, lumaSouthEast)));
    float lumaRange = lumaMaximum - lumaMinimum;
    float edgeThreshold = max(FXAA_EDGE_THRESHOLD_MINIMUM,
                              lumaMaximum * FXAA_EDGE_THRESHOLD);
    if (lumaRange < edgeThreshold) return center;

    vec2 direction;
    direction.x = -((lumaNorthWest + lumaNorthEast)
                  - (lumaSouthWest + lumaSouthEast));
    direction.y =  ((lumaNorthWest + lumaSouthWest)
                  - (lumaNorthEast + lumaSouthEast));

    float directionReduce = max((lumaNorthWest + lumaNorthEast
                               + lumaSouthWest + lumaSouthEast)
                               * (0.25 * FXAA_SUBPIXEL), 1.0 / 128.0);
    float reciprocalMinimum = 1.0
        / (min(abs(direction.x), abs(direction.y)) + directionReduce);
    direction = clamp(direction * reciprocalMinimum,
                      vec2(-FXAA_SPAN_MAX), vec2(FXAA_SPAN_MAX))
              * inverseResolution;

    vec3 sampleA = 0.5 * (
        texture(colortex0, uv + direction * (1.0 / 3.0 - 0.5)).rgb
      + texture(colortex0, uv + direction * (2.0 / 3.0 - 0.5)).rgb);
    vec3 sampleB = sampleA * 0.5 + 0.25 * (
        texture(colortex0, uv + direction * -0.5).rgb
      + texture(colortex0, uv + direction *  0.5).rgb);

    float lumaB = fxaaLuma(sampleB);
    vec3 resolved = (lumaB < lumaMinimum || lumaB > lumaMaximum)
        ? sampleA
        : sampleB;
    return vec4(resolved, center.a);
}

void main() {
#ifdef FXAA_ENABLED
    gl_FragColor = stableFxaa(texCoord);
#else
    gl_FragColor = texture(colortex0, texCoord);
#endif
}
